//
//  NSString+Utils.h
//  hxb
//
//  Created by FangDe on 16/1/11.
//  Copyright © 2016年 NFS. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ELMeLoginModel.h"
#import "ELUserID.h"
#import "ELBPushChannelID.h"
@interface NSString (Utils)
/**判断字符串为空*/
+ (BOOL)isEmpty:(NSString *)string;
/**存储userid*/
+ (void)saveUserIDToSandBox:(ELUserID *)userid;
/**获取userid*/
+ (NSString *)getUserIDFromSandBox;
/**存储用户登录信息*/
+ (void)saveUserInfoFromLogin:(ELMeLoginModel *)loginModel;
/**获取用户登录信息*/
+ (ELMeLoginModel *)getUserInfoFromLogin;
/**检查登录状态*/
+ (BOOL)checkLoginStatus;
/**检查本地是否存储userId*/
+ (BOOL)checkUserID;
/**存储bpushChannelId百度推送channelid*/
+ (void)saveBPushChannelIdToSandBox:(ELBPushChannelID *)bpushChannelId;
/**获取bpushChannelId百度推送channelid*/
+ (NSString *)getBPushChannelIdFormSandBox;

/**
 根据字体重新设置高度、宽度等尺寸
 */
+ (CGFloat)heightWithFontSize:(CGFloat)fontSize;
- (CGSize)sizeWithFontSize:(CGFloat)fontSize;
- (CGRect)boundingRectWithWidth:(CGFloat)width fontSize:(CGFloat)fontSize;
- (CGRect)boundingRectWithWidth:(CGFloat)width fontSize:(CGFloat)fontSize lineSpacing:(CGFloat)lineSpacing;

@end
