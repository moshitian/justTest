//
//  oneViewController.m
//  ooooo
//
//  Created by 李金蔚 on 16/12/2.
//  Copyright © 2016年 SYP. All rights reserved.
//

#import "oneViewController.h"

//一定要先配置自己项目在商店的APPID,配置完最好在真机上运行才能看到完全效果哦!
#define STOREAPPID    @"1123864769"
#define SCREEN_WIDTH  [UIScreen mainScreen].bounds.size.width
#define SCREEN_HEIGHT [UIScreen mainScreen].bounds.size.height


@interface oneViewController ()

@property (nonatomic,copy)  NSString    * message;
@property (nonatomic,assign)id            delegate;
@property (nonatomic,copy)  NSString    * cancelButtonTitleName;
@property (nonatomic,strong)UIView      * contentView;
@property (nonatomic,strong)UIImageView * iconimageview;
@property(nonatomic,strong) NSString    * imageName;
@property (nonatomic,strong)UILabel     * messageLabel;
@property (nonatomic,strong)UIButton    * cancelBtn;
@property (nonatomic,assign)CGFloat       width;
@property (nonatomic,assign)CGFloat       height;

@end

@implementation oneViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor =[UIColor whiteColor];
}

-(instancetype)initInFullWindowWithTitle:(NSString *)title message:(NSString *)message delegate:(id)delegate cancelButtonTitle:(NSString *)cancelButtonTitleName rightBtnTitle:(NSString *)rightBtnTitleName width:(CGFloat)width height:(CGFloat)height imageName:(NSString *)imageName
{
    self=[super init];
    if (self) {
        self.message=message;
        self.delegate=delegate;
        self.cancelButtonTitleName=cancelButtonTitleName;
        self.width = width;
        self.height = height;
        self.imageName = imageName;
        [self createUI];
        
    }
    return self;
}

#pragma mark - 创建UI界面

-(void)createUI{

    self.view.frame =CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
    //添加阴影背景view
    UIView * shadowView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, self.width, self.height)];
    shadowView.backgroundColor=[UIColor blackColor];
    shadowView.alpha=0.5;
    shadowView.userInteractionEnabled = YES;
    [self.view addSubview:shadowView];
    //添加弹框view
    self.contentView=[[UIView alloc]initWithFrame:CGRectMake(0, 0,270, 270)];
    self.contentView.center = shadowView.center;

    self.contentView.backgroundColor=[UIColor whiteColor];
    self.contentView.layer.cornerRadius=6.0;
    self.contentView.clipsToBounds=YES;
    self.contentView.userInteractionEnabled = YES;
    [self.view addSubview:self.contentView];
    //添加图片
    if (self.imageName) {
        self.iconimageview =[[UIImageView alloc]init];
        self.iconimageview.frame =CGRectMake(0,0, 270, 160);
        self.iconimageview.image =[UIImage imageNamed:self.imageName];
        self.iconimageview.backgroundColor =[UIColor yellowColor];
        self.iconimageview.userInteractionEnabled = YES;
        [self.contentView addSubview:self.iconimageview];
    }
    
    //添加文字提示信息
    self.messageLabel =[[UILabel alloc]initWithFrame:CGRectMake(12, 160+10, 270-24, 40)];
    self.messageLabel.font = [UIFont systemFontOfSize:11];
    self.messageLabel.textColor = [UIColor blackColor];
    self.messageLabel.numberOfLines = 2;
    self.messageLabel.text = self.message;
    self.messageLabel.textAlignment = NSTextAlignmentCenter;
    [self.contentView addSubview:self.messageLabel];
    
    //取消button
    self.cancelBtn=[[UIButton alloc]init];
    self.cancelBtn.frame=CGRectMake(30, 221, 215, 28);
    self.cancelBtn.titleLabel.font=[UIFont systemFontOfSize:14];
    [self.cancelBtn setTitleColor:[UIColor colorWithHex:BLUE_COLOR] forState:UIControlStateNormal];
    self.cancelBtn.backgroundColor =[UIColor whiteColor];
    self.cancelBtn.layer.borderColor = [UIColor colorWithHex:BLUE_COLOR].CGColor;
    self.cancelBtn.layer.borderWidth= 1;
    [self.cancelBtn setTitle:self.cancelButtonTitleName forState:UIControlStateNormal];
    self.cancelBtn.tag = 10009;
    [self.cancelBtn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.contentView addSubview:self.cancelBtn];

}

-(void)btnClick:(UIButton *)btn
{
    //此处加入应用在app store的地址，方便用户去更新，一种实现方式如下
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"https://itunes.apple.com/us/app/id%@?ls=1&mt=8", STOREAPPID]];
    [[UIApplication sharedApplication] openURL:url];
    [self dismissViewControllerAnimated:NO completion:nil];
}


@end
