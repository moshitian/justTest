//
//  MBProgressHUD+Utils.h
//  HuaXiaELife
//
//  Created by 李金蔚 on 16/9/3.
//  Copyright © 2016年 SYP. All rights reserved.
//

#import <MBProgressHUD/MBProgressHUD.h>

@interface MBProgressHUD (Utils)
///--需要手动取消的load框
+ (MBProgressHUD *)showHUD:(UIView *)view;
+ (MBProgressHUD *)showHUD:(UIView *)view text:(NSString *)text;
+ (MBProgressHUD *)showHUD:(UIView *)view text:(NSString *)text mode:(MBProgressHUDMode)mode;
+ (void)hideHUD:(UIView *)view;
///--根据文本的长度自动设置隐藏时间后隐藏
+ (MBProgressHUD *)showAutoHideHUD:(UIView *)view text:(NSString *)text;
+ (MBProgressHUD *)showAutoHideHUD:(UIView *)view text:(NSString *)text mode:(MBProgressHUDMode)mode;
///--显示自定义的view，可以添加图片、文字颜色等
+ (MBProgressHUD *)showSuccessHUD:(UIView *)view text:(NSString *)text;
+ (MBProgressHUD *)showErrorHUD:(UIView *)view text:(NSString *)text;
+ (MBProgressHUD *)showInfoHUD:(UIView *)view text:(NSString *)text;

@end
