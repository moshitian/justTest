//
//  UIColor+Utils.m
//  hxb
//
//  Created by WeiXinxing on 15/12/22.
//  Copyright © 2015年 NFS. All rights reserved.
//

#import "UIColor+Utils.h"

@implementation UIColor (Utils)

+ (UIColor *)colorWithHex:(NSInteger)hex
{
    return [self colorWithHex:hex alpha:1.0];
}

+ (UIColor *)colorWithHex:(NSInteger)hex alpha:(CGFloat)alpha
{
    NSInteger red = (hex >> 16) & 0xFF;
    NSInteger green = (hex >> 8) & 0xFF;
    NSInteger blue = hex & 0xFF;
    return [UIColor colorWithRed:red/255.0 green:green/255.0 blue:blue/255.0 alpha:alpha];
}

+ (UIColor *)highlightColorWithHex:(NSInteger)hex
{
    return [self highlightColorWithHex:hex alpha:0.85];
}

+ (UIColor *)highlightColorWithHex:(NSInteger)hex alpha:(CGFloat)alpha
{
    NSInteger red = ((hex >> 16) & 0xFF) >> 2;
    NSInteger green = ((hex >> 8) & 0xFF) >> 2;
    NSInteger blue = (hex & 0xFF) >> 2;
    return [UIColor colorWithRed:red/255.0 green:green/255.0 blue:blue/255.0 alpha:alpha];
}

@end
