//
//  NSString+Utils.m
//  hxb
//
//  Created by FangDe on 16/1/11.
//  Copyright © 2016年 NFS. All rights reserved.
//

#import "NSString+Utils.h"


@implementation NSString (Utils)

+ (BOOL)isEmpty:(NSString *)string
{
    return string == nil || string.length == 0;
}
+ (void)saveUserIDToSandBox:(ELUserID *)userid{
    NSString * path =[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES)lastObject];
    NSString * filePath =[path stringByAppendingPathComponent:@"userId.txt"];
    [NSKeyedArchiver archiveRootObject:userid toFile:filePath];
}
+ (NSString *)getUserIDFromSandBox{
    
    NSString * path =[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)lastObject];
    NSString * filePath = [path stringByAppendingPathComponent:@"userId.txt"];
    ELUserID * user = [NSKeyedUnarchiver unarchiveObjectWithFile:filePath];
    return user.userId;
    
}
+(void)saveUserInfoFromLogin:(ELMeLoginModel *)loginModel{
    NSString * path =[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES)lastObject];
    NSString * filePath =[path stringByAppendingPathComponent:@"userInfo.txt"];
    [NSKeyedArchiver archiveRootObject:loginModel toFile:filePath];
}

+ (void)saveBPushChannelIdToSandBox:(ELBPushChannelID *)bpushChannelId{
    NSString * path =[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES)lastObject];
    NSString * filePath =[path stringByAppendingPathComponent:@"bpushChannelId.txt"];
    [NSKeyedArchiver archiveRootObject:bpushChannelId toFile:filePath];
}

+ (NSString *)getBPushChannelIdFormSandBox{
    NSString * path =[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)lastObject];
    NSString * filePath = [path stringByAppendingPathComponent:@"bpushChannelId.txt"];
    ELBPushChannelID * bpushChannelId = [NSKeyedUnarchiver unarchiveObjectWithFile:filePath];
    return bpushChannelId.bpushChannelId;
}

+ (ELMeLoginModel *)getUserInfoFromLogin{
    
    NSString * path =[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)lastObject];
    NSString * filePath = [path stringByAppendingPathComponent:@"userInfo.txt"];
    ELMeLoginModel * userInfoModel = [NSKeyedUnarchiver unarchiveObjectWithFile:filePath];
    return userInfoModel;
}

+ (BOOL)checkLoginStatus{
    
    ELMeLoginModel * userInfoModel = [self getUserInfoFromLogin];
    if (userInfoModel == nil || [[NSString stringWithFormat:@"%@",userInfoModel.userId] isEqualToString:@""] || userInfoModel.userId == nil) {
        return NO;
    }else{
       return YES;
    }
}

+ (BOOL)checkUserID{
    NSString * userId = [self getUserIDFromSandBox];
    if ([[NSString stringWithFormat:@"%@",userId] isEqualToString:@""] || userId == nil) {
        return NO;
    }else{
        return YES;
    }
}

+ (CGFloat)heightWithFontSize:(CGFloat)fontSize
{
    return [@" " sizeWithAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:fontSize]}].height;
}

- (CGSize)sizeWithFontSize:(CGFloat)fontSize
{
    return [self sizeWithAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:fontSize]}];
}

- (CGRect)boundingRectWithWidth:(CGFloat)width fontSize:(CGFloat)fontSize
{
    @autoreleasepool {
        CGRect rect = [self boundingRectWithSize:CGSizeMake(width, 0)
                                               options:NSStringDrawingUsesLineFragmentOrigin|NSStringDrawingUsesFontLeading
                                            attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:fontSize]}
                                               context:nil];
        rect.size.height = ceil(rect.size.height);
        return rect;
    }
}

- (CGRect)boundingRectWithWidth:(CGFloat)width fontSize:(CGFloat)fontSize lineSpacing:(CGFloat)lineSpacing
{
    @autoreleasepool {
        NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc] init];
        [style setLineSpacing:lineSpacing];
        NSMutableDictionary *attrs = [[NSMutableDictionary alloc] initWithCapacity:2];
        [attrs setObject:style forKey:NSParagraphStyleAttributeName];
        [attrs setObject:[UIFont systemFontOfSize:fontSize] forKey:NSFontAttributeName];
        
        CGRect rect = [self boundingRectWithSize:CGSizeMake(width, MAXFLOAT)
                                               options:NSStringDrawingUsesLineFragmentOrigin|NSStringDrawingUsesFontLeading
                                            attributes:attrs
                                               context:nil];
        rect.size.height = ceil(rect.size.height);
        return rect;
    }
}


@end
