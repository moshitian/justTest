//
//  oneViewController.h
//  ooooo
//
//  Created by 李金蔚 on 16/12/2.
//  Copyright © 2016年 SYP. All rights reserved.
//

#import <UIKit/UIKit.h>

@class  oneViewController;
@protocol ELAlertControllerDelegate <NSObject>

@required

- (void)ELAlertViewClickedAtIndex:(NSInteger)index alertController:(oneViewController *)alertController;

@end

@interface oneViewController : UIViewController

-(instancetype)initInFullWindowWithTitle:(NSString *)title message:(NSString *)message delegate:(id)delegate cancelButtonTitle:(NSString *)cancelButtonTitleName rightBtnTitle:(NSString *)rightBtnTitleName width:(CGFloat)width height:(CGFloat)height imageName:(NSString *)imageName;
@end
