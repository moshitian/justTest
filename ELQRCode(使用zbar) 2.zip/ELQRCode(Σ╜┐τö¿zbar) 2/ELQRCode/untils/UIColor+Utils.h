//
//  UIColor+Utils.h
//  hxb
//
//  Created by WeiXinxing on 15/12/22.
//  Copyright © 2015年 NFS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (Utils)
/**
 根据颜色传入的八位换成RGB显示
 */
+ (UIColor *)colorWithHex:(NSInteger)hex;
+ (UIColor *)colorWithHex:(NSInteger)hex alpha:(CGFloat)alpha;
+ (UIColor *)highlightColorWithHex:(NSInteger)hex;
+ (UIColor *)highlightColorWithHex:(NSInteger)hex alpha:(CGFloat)alpha;

@end
