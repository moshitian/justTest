//
//  UIApplication+Utils.h
//  hxb
//
//  Created by WeiXinxing on 16/3/30.
//  Copyright © 2016年 NFS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIApplication (Utils)
/**
 系统的方法
 */
//+ (void)openSystemSetting;
//拨打电话
+ (void)openSystemDial:(NSString *)mobile;
//打开连接
+ (void)openURL:(NSURL *)URL;
//获取App名称
+ (NSString *)applicationName;
//获取RootViewController
+ (UIViewController *)rootViewController;
//获取系统Window
+ (UIWindow *)window;
//设置icon的角标数字
+ (void)setIconBadgeNumber:(NSInteger)num;
//+ (void)registerRemoteNotification;

@end
