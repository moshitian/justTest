//
//  MBProgressHUD+Utils.m
//  HuaXiaELife
//
//  Created by 李金蔚 on 16/9/3.
//  Copyright © 2016年 SYP. All rights reserved.
//

#import "MBProgressHUD+Utils.h"
#define MBPROGRESSHUD_TAG   9999
@implementation MBProgressHUD (Utils)
+ (NSTimeInterval)displayDurationForText:(NSString *)text
{
    NSTimeInterval duration = text.length * 0.06 + 1.0;
    return MIN(duration, 2); // max is 2 sec
}

+ (MBProgressHUD *)showHUD:(UIView *)view
{
    return [self showHUD:view text:nil];
}

+ (MBProgressHUD *)showHUD:(UIView *)view text:(NSString *)text
{
    return [self showHUD:view text:text mode:MBProgressHUDModeIndeterminate];
}

+ (MBProgressHUD *)showHUD:(UIView *)view text:(NSString *)text mode:(MBProgressHUDMode)mode
{
    if (!view) {
        return nil;
    }
    
    MBProgressHUD *hud = [view viewWithTag:MBPROGRESSHUD_TAG];
    if (!hud) {
        hud = [MBProgressHUD showHUDAddedTo:view animated:YES];
        hud.tag = MBPROGRESSHUD_TAG;
        hud.minSize = CGSizeMake(120, 40);
    }
    hud.labelText = text;
    hud.labelFont = [UIFont boldSystemFontOfSize:15];
    hud.mode = mode;
    return hud;
}

+ (void)hideHUD:(UIView *)view
{
    MBProgressHUD *hud = [view viewWithTag:MBPROGRESSHUD_TAG];
    [hud hide:YES];
}

+ (MBProgressHUD *)showAutoHideHUD:(UIView *)view text:(NSString *)text
{
    return [self showAutoHideHUD:view text:text mode:MBProgressHUDModeText];
}

+ (MBProgressHUD *)showAutoHideHUD:(UIView *)view text:(NSString *)text mode:(MBProgressHUDMode)mode
{
    MBProgressHUD *hud = [self showHUD:view text:text mode:mode];
    [hud hide:YES afterDelay:[self displayDurationForText:text]];
    return hud;
}

+ (UIImageView *)imageViewNamed:(NSString *)name withTintColor:(UIColor *)color
{
    UIImage *image = [UIImage imageNamed:name];
    //    if (image.renderingMode != UIImageRenderingModeAlwaysTemplate) {
    //        image = [image imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
    //    }
    UIImageView *view = [[UIImageView alloc] initWithImage:image];
    //    view.tintColor = color;
    
    return view;
}

+ (MBProgressHUD *)showSuccessHUD:(UIView *)view text:(NSString *)text
{
    MBProgressHUD *hud = [self showAutoHideHUD:view text:text mode:MBProgressHUDModeCustomView];
    hud.customView = [self imageViewNamed:@"OK" withTintColor:hud.labelColor];
    return hud;
}

+ (MBProgressHUD *)showErrorHUD:(UIView *)view text:(NSString *)text
{
    MBProgressHUD *hud = [self showAutoHideHUD:view text:text mode:MBProgressHUDModeCustomView];
    hud.customView = [self imageViewNamed:@"hud_error" withTintColor:hud.labelColor];
    return hud;
}

+ (MBProgressHUD *)showInfoHUD:(UIView *)view text:(NSString *)text
{
    MBProgressHUD *hud = [self showAutoHideHUD:view text:text mode:MBProgressHUDModeCustomView];
    hud.customView = [self imageViewNamed:@"OK" withTintColor:hud.labelColor];
    return hud;
}

@end
