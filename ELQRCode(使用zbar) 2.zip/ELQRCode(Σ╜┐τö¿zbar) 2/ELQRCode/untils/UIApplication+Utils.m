//
//  UIApplication+Utils.m
//  hxb
//
//  Created by WeiXinxing on 16/3/30.
//  Copyright © 2016年 NFS. All rights reserved.
//

#import "UIApplication+Utils.h"
#import <UserNotifications/UserNotifications.h>

@implementation UIApplication (Utils)

//+ (void)openSystemSetting
//{
//    NSURL *settingURL = nil;
//    if (&UIApplicationOpenSettingsURLString != nil) {
//        settingURL = [NSURL URLWithString:UIApplicationOpenSettingsURLString];
//    } else {
//        settingURL = [NSURL URLWithString:@"app-settings:"];
//    }
//    if (settingURL && [[UIApplication sharedApplication] canOpenURL:settingURL]) {
//        [[UIApplication sharedApplication] openURL:settingURL];
//    }
//}

+ (NSString *)applicationName
{
    static NSString *appname;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        appname = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleName"];
    });
    return appname;
}

+ (UIViewController *)rootViewController
{
    return [[UIApplication sharedApplication].delegate window].rootViewController;
}

+ (UIWindow *)window
{
    return [[UIApplication sharedApplication].delegate window];
}

+ (void)setIconBadgeNumber:(NSInteger)num
{
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber:num];
}
///**注册远程推送*/
//+ (void)registerRemoteNotification
//{
//    
//   
//
//    
//    // iOS8 下需要使用新的 API
//    if (HXOSVersionGE(8.0)) {
//        UIUserNotificationType myTypes = UIUserNotificationTypeBadge | UIUserNotificationTypeSound | UIUserNotificationTypeAlert;
//        
//        UIUserNotificationSettings *settings = [UIUserNotificationSettings settingsForTypes:myTypes categories:nil];
//        [[UIApplication sharedApplication] registerUserNotificationSettings:settings];
//    }else {
//        UIRemoteNotificationType myTypes = UIRemoteNotificationTypeBadge|UIRemoteNotificationTypeAlert|UIRemoteNotificationTypeSound;
//        [[UIApplication sharedApplication] registerForRemoteNotificationTypes:myTypes];
//    }
//}

+ (void)openSystemDial:(NSString *)mobile
{
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"telprompt://%@", mobile]];
    if ([[UIApplication sharedApplication] canOpenURL:url]) {
        [[UIApplication sharedApplication] openURL:url];
    }
}

+ (void)openURL:(NSURL *)URL
{
    if (URL && [[UIApplication sharedApplication] canOpenURL:URL]) {
        [[UIApplication sharedApplication] openURL:URL];
    }
}

@end
