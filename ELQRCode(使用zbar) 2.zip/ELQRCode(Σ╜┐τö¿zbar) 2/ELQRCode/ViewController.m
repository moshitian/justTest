//
//  ViewController.m
//  ELQRCode
//
//  Created by 李金蔚 on 17/8/7.
//  Copyright © 2017年 SYP. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

-(instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    if (self =[super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        self.hidesBottomBarWhenPushed = YES;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [self setupData];
    [self setupSubviews];
    [self loadDataFromNetwork];
}


- (void)setupData
{
}

- (void)setupSubviews
{
    
}

- (void)loadDataFromNetwork
{
    
}



@end
