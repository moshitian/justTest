//
//  ELHttpClient.m
//  ELQRCode
//
//  Created by 李金蔚 on 17/8/7.
//  Copyright © 2017年 SYP. All rights reserved.
//

#import "ELHttpClient.h"

#import <AFNetworking/AFNetworking.h>
#import "oneViewController.h"

//获取IP地址
#import <sys/socket.h>
#import <sys/sockio.h>
#import <sys/ioctl.h>
#import <net/if.h>
#import <arpa/inet.h>


#import "ELSession.h"

#define NUMBER_OF_KEY  8
///一定要先配置自己项目在商店的APPID,配置完最好在真机上运行才能看到完全效果哦!
#define STOREAPPID     @"1123864769"
///存储channelID
#define BPUSH_KEY       @"BPUSH_KEY"

@interface ELHttpClient ()

@property(nonatomic,assign) float      version;
@property(nonatomic,strong) NSString * sessionId;
//修改网络
@property(nonatomic,strong) AFHTTPSessionManager * manager;
@end


@implementation ELHttpClient

+ (instancetype)shareManage{
    static ELHttpClient *instance;
    static dispatch_once_t onceToken;
    
    dispatch_once(&onceToken, ^{
        instance = [[self alloc] init];
    });
    return instance;
}

- (instancetype)init{
    if (self = [super init]) {
        self.manager =[[AFHTTPSessionManager alloc] initWithSessionConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
        self.manager.requestSerializer =[AFHTTPRequestSerializer serializer];
        self.manager.responseSerializer=[AFHTTPResponseSerializer serializer];
        // 设置超时时间
        self.manager.requestSerializer.timeoutInterval = 4.f;
    }
    return self;
}

-(void)PamramsResultOne{
    
    //得到当前的机型，传给后台，后台判断是苹果还是安卓；但是苹果已经写死了数值为4，不用实际获取了
    NSString * device = @"4";
    double version =[self getVersion];
    NSString * ip =[self getDeviceIPIpAddresses];
    //5.获取用户id
    NSString * userID = [NSString getUserIDFromSandBox];
    if (![NSString checkUserID]) {
        userID = @"";
    }
    //6.封装为json
    NSDictionary * Parameter =@{@"mobileDevice":device,@"appVersion":[NSString stringWithFormat:@"%.2f",version],@"ip":ip};
    YYLog(@"测试版本的号看看%@",[NSString stringWithFormat:@"%.2f",version]);
    NSString * Parameterjson = [Parameter mj_JSONString];
    
    NSDictionary * dict = @{@"data":Parameterjson,@"userId":userID};
    
    [self.manager POST:FIRST_URL parameters:dict progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        if (responseObject) {
            //解析json
            id json = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
            
            //code 0：普通请求成功！1：业务逻辑错，提醒用户message  2:第一次通讯成功！3：重放攻击！4：数据被篡改
            if ([[NSString stringWithFormat:@"%@",json[@"code"]] isEqualToString:@"2"]) {
                [self handleFirstRequestResult:json];
            }else{
                [MBProgressHUD showErrorHUD:[UIApplication window] text:json[@"服务器异常,请稍后再试"]];
            }
        }else{
            [MBProgressHUD showAutoHideHUD:[UIApplication window] text:@"请检查网络"];
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
        [MBProgressHUD showAutoHideHUD:[UIApplication window] text:@"请检查网络"];
    }];
}
///处理第一请求的结果
- (void)handleFirstRequestResult:(id)json{
    YYLog(@"第一次请求成功");
    NSString * sessionId = json[@"data"][@"sessionId"];
    
    self.sessionId =sessionId;
    //对sessionId desKey进行归档
    //需要强制更新
    if ([[NSString stringWithFormat:@"%@",json[@"data"][@"isForceUpdate"]] isEqualToString:@"1"]) {
        oneViewController * controller = [[oneViewController alloc] initInFullWindowWithTitle:@"" message:@"亲，您当前的版本太旧了，为避免影响到您的使用，请更新到最新版本！" delegate:nil cancelButtonTitle:@"立即更新" rightBtnTitle:nil width:375 height:414 imageName:@"edition.jpg"];
        [[UIApplication rootViewController] presentViewController:controller animated:NO completion:nil];
    }
    NSDictionary * sdict =[[NSDictionary alloc]initWithObjectsAndKeys:sessionId,@"sessionId", nil];
    ELSession * session =[ELSession sessionWithDict:sdict];
    NSString * path =[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES)lastObject];
    NSString * filePath =[path stringByAppendingPathComponent:@"desKey.txt"];
    BOOL isArchive = [NSKeyedArchiver archiveRootObject:session toFile:filePath];
    if (isArchive) {
        [self postChannelToService];
    }else{
    }
}

- (void)postChannelToService{
    
    NSString * bpushChannelId = [NSString getBPushChannelIdFormSandBox];
    if (bpushChannelId == nil || [bpushChannelId isEqualToString:@""]) {
        bpushChannelId = @"1234567";
    }
    NSDictionary * dict = @{@"channelId":bpushChannelId};
    
    [self PamramsResultTwoWithParameter:dict URL:@"" result:^(NSDictionary *json) {
       
    }];
}

#pragma mark - 注意IP地址的更换
-(void)PamramsResultTwoWithParameter:(NSDictionary *)Parameter URL:(NSString *)url result:(getResult)getResult{
    
    //3.封装为json
    NSString *Parameterjson =  [Parameter mj_JSONString];
    //4.对归档进行解档
    NSString * path =[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)lastObject];
    NSString * filePath = [path stringByAppendingPathComponent:@"desKey.txt"];
    ELSession * session = [NSKeyedUnarchiver unarchiveObjectWithFile:filePath];
    //6.获取用户id
    NSString * userID = [NSString getUserIDFromSandBox];
    if (![NSString checkUserID]) {
        userID = @"";
    }
    NSString * SessionID = session.sessionId;
    //判断sessionid是否为空，如果空，掉第一次请求，然后在掉普通请求
    if (SessionID == nil || [SessionID isEqualToString:@""]) {
        [self PamramsResultOne];
        YYLog(@"session为空调取的");
        return;
    }
    NSDictionary * dict =@{@"data":Parameterjson,@"sessionId":SessionID,@"userId":userID};
    
    NSString * urlString =[NSString stringWithFormat:@"%@%@",NORMAL_URL,url];
    
    [self.manager POST:urlString parameters:dict progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        if (responseObject) {
            //解析json
            id json = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
            
            //判断sessionId是否失效，如果失效就调取第一次通讯的接口
            if ([json isEqual:@""] || json == nil) {
                [self PamramsResultOne];
                [MBProgressHUD showAutoHideHUD:[UIApplication window] text:@"请检查网络"];
            }else if ([[NSString stringWithFormat:@"%@",json[@"code"]] isEqualToString:@"1"]) {
                [self loginInformationExpired];
                
            }else if ([[NSString stringWithFormat:@"%@",json[@"code"]] isEqualToString:@"5"]){
                [self offsiteLogin];
            }else{
                getResult(json);
            }
        }else{
            [MBProgressHUD showAutoHideHUD:[UIApplication window] text:@"请检查网络"];
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
         [MBProgressHUD showAutoHideHUD:[UIApplication window] text:@"请检查网络"];
    }];
}
// --图片上传
-(void)uploadImageResultWithParameter:(NSDictionary *)Parameter Image:(UIImage *)photo URL:(NSString *)url result:(getResult)getResult{
    
    //3.封装为json
    NSString *Parameterjson =  [Parameter mj_JSONString];
    //4.对归档进行解档
    NSString * path =[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)lastObject];
    NSString * filePath = [path stringByAppendingPathComponent:@"desKey.txt"];
    ELSession * session = [NSKeyedUnarchiver unarchiveObjectWithFile:filePath];
    
    NSString * SessionID = session.sessionId;
    //判断sessionid是否为空，如果空，掉第一次请求，然后在掉普通请求
    if (SessionID == nil || [SessionID isEqualToString:@""]) {
        [self PamramsResultOne];
        return;
    }
    NSDictionary * dict =@{@"data":Parameterjson,@"sessionId":SessionID};
    
    NSString * urlString =[NSString stringWithFormat:@"%@%@",NORMAL_URL,url];
    NSData * imageData =[self imageData:photo];
    
    [self.manager POST:urlString parameters:dict constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        
        [formData appendPartWithFileData:imageData name:@"imgBuffer" fileName:@"themeImage" mimeType:@"image/jpg"];
    } progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        if (responseObject) {
            //解析json
            id json = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
            //判断sessionId是否失效，如果失效就调取第一次通讯的接口
            if ([json isEqual:@""] || json == nil) {
                [self PamramsResultOne];
            }else  if ([[NSString stringWithFormat:@"%@",json[@"code"]] isEqualToString:@"1"]) {
                [self loginInformationExpired];
            }else if ([[NSString stringWithFormat:@"%@",json[@"code"]] isEqualToString:@"5"]){
                [self offsiteLogin];
            }else{
                getResult(json);
            }
        }else{
            [MBProgressHUD showAutoHideHUD:[UIApplication window] text:@"请检查网络"];
        }
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        [MBProgressHUD showAutoHideHUD:[UIApplication window] text:@"请检查网络"];
    }];
}

///登录信息过期
- (void)loginInformationExpired{
    UIAlertController * alert =[UIAlertController alertControllerWithTitle:nil message:@"登录信息过期，请重新登录" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction * action =[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        //清除用户信息
        ELMeLoginModel * userInfoModel = [[ELMeLoginModel alloc]init];
        [NSString saveUserInfoFromLogin:userInfoModel];
        NSDictionary * dict = @{@"userId":@""};
        ELUserID * userId =[ELUserID sessionWithDict:dict];
        [NSString saveUserIDToSandBox:userId];
        //弹出登录界面，让用户重新登录
        [[NSNotificationCenter defaultCenter]postNotificationName:@"HXApplicationLoginInvalidNotification" object:nil userInfo:nil];
    }];
    [alert addAction:action];
    [self execAlertController:alert];
}
///异地登录
- (void)offsiteLogin{
    UIAlertController * alert =[UIAlertController alertControllerWithTitle:nil message:@"您的账号被异地登录，是否确定重新登录？" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction * action =[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        //清除用户信息
        ELMeLoginModel * userInfoModel = [[ELMeLoginModel alloc]init];
        [NSString saveUserInfoFromLogin:userInfoModel];
        NSDictionary * dict = @{@"userId":@""};
        ELUserID * userId =[ELUserID sessionWithDict:dict];
        [NSString saveUserIDToSandBox:userId];
    }];
    [alert addAction:action];
    UIAlertAction * actionConfirm =[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        //清除用户信息
        ELMeLoginModel * userInfoModel = [[ELMeLoginModel alloc]init];
        [NSString saveUserInfoFromLogin:userInfoModel];
        NSDictionary * dict = @{@"userId":@""};
        ELUserID * userId =[ELUserID sessionWithDict:dict];
        [NSString saveUserIDToSandBox:userId];
        //弹出登录界面，让用户重新登录
        [[NSNotificationCenter defaultCenter]postNotificationName:@"HXApplicationLoginInvalidNotification" object:nil userInfo:nil];
    }];
    [alert addAction:actionConfirm];
    [self execAlertController:alert];
}


- (void)saveBPushChannelId
{
    if (self.bpushChannelId) {
        [[NSUserDefaults standardUserDefaults] setObject:self.bpushChannelId forKey:BPUSH_KEY];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
}
//压缩图片至100k以下
-(NSData *)imageData:(UIImage *)myimage
{
    NSData *data=UIImageJPEGRepresentation(myimage, 1.0);
    if (data.length>100*1024) {
        if (data.length>1024*1024) {//>=1M
            //模拟器选择图片的时候，压缩比在0.45-0.5，图片的质量大小会控制在1M左右;
            data=UIImageJPEGRepresentation(myimage, 0.01);
        }else if (data.length>512*1024) {//0.5M-1M
            data=UIImageJPEGRepresentation(myimage, 0.25);
        }else if (data.length>200*1024) {//0.25M-0.5M
            data=UIImageJPEGRepresentation(myimage, 0.75);
        }
    }
    return data;
}

-(void)execAlertController:(UIAlertController *)alert{
    [[UIApplication rootViewController] presentViewController:alert animated:YES completion:nil];
}

//获取本地的版本号
-(float)getVersion{
    NSDictionary * infoDict =[[NSBundle mainBundle]infoDictionary];
    NSString * currentVersion =[infoDict objectForKey:@"CFBundleVersion"];
    return currentVersion.doubleValue;
}

//获取手机端的IP地址
- (NSString *)getDeviceIPIpAddresses
{
    int sockfd =socket(AF_INET,SOCK_DGRAM, 0);
    //    if (sockfd <</span> 0) return nil;
    NSMutableArray *ips = [NSMutableArray array];
    int BUFFERSIZE =4096;
    struct ifconf ifc;
    char buffer[BUFFERSIZE], *ptr, lastname[IFNAMSIZ], *cptr;
    struct ifreq *ifr, ifrcopy;
    ifc.ifc_len = BUFFERSIZE;
    ifc.ifc_buf = buffer;
    if (ioctl(sockfd,SIOCGIFCONF, &ifc) >= 0){
        for (ptr = buffer; ptr < buffer + ifc.ifc_len; ){
            ifr = (struct ifreq *)ptr;
            int len =sizeof(struct sockaddr);
            if (ifr->ifr_addr.sa_len > len) {
                len = ifr->ifr_addr.sa_len;
            }
            ptr += sizeof(ifr->ifr_name) + len;
            if (ifr->ifr_addr.sa_family !=AF_INET) continue;
            if ((cptr = (char *)strchr(ifr->ifr_name,':')) != NULL) *cptr =0;
            if (strncmp(lastname, ifr->ifr_name,IFNAMSIZ) == 0)continue;
            memcpy(lastname, ifr->ifr_name,IFNAMSIZ);
            ifrcopy = *ifr;
            ioctl(sockfd,SIOCGIFFLAGS, &ifrcopy);
            if ((ifrcopy.ifr_flags &IFF_UP) == 0)continue;
            NSString *ip = [NSString stringWithFormat:@"%s",inet_ntoa(((struct sockaddr_in *)&ifr->ifr_addr)->sin_addr)];
            [ips addObject:ip];
        }
    }
    close(sockfd);
    NSString *deviceIP =@"";
    for (int i=0; i < ips.count; i++)
    {
        if (ips.count >0)
        {
            deviceIP = [NSString stringWithFormat:@"%@",ips.lastObject];
        }
    }
    return deviceIP;
}



@end







