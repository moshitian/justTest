//
//  ELUserID.h
//  HuaXiaELife
//
//  Created by 李金蔚 on 16/9/3.
//  Copyright © 2016年 SYP. All rights reserved.
//

#import <Foundation/Foundation.h>
//归档userId
@interface ELUserID : NSObject<NSCoding>
@property(nonatomic,strong)NSString * userId;
+(instancetype)sessionWithDict:(NSDictionary *)dict;


@end
