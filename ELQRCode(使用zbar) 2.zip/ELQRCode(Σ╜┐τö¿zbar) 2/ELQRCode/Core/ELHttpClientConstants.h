//
//  ELHttpClientConstants.h
//  ELQRCode
//
//  Created by 李金蔚 on 17/8/8.
//  Copyright © 2017年 SYP. All rights reserved.
//

#ifndef ELHttpClientConstants_h
#define ELHttpClientConstants_h

/**************************************BASE_URL*********************************/

#define FIRST_URL     @"http://192.168.1.208:8080/HuaXiaEManager/user/getFirstCommunication.do"
#define NORMAL_URL    @"http://192.168.1.208:8080/HuaXiaEManager"


////阿里云 -HTTPS
//#define FIRST_URL     @"https://yiishequ.com/HuaXiaEManager/user/getFirstCommunication.do"
//#define NORMAL_URL    @"https://yiishequ.com/HuaXiaEManager"


#endif /* ELHttpClientConstants_h */

















