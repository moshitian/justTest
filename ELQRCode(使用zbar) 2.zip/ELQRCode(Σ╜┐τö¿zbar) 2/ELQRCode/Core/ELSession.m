//
//  ELSession.m
//  DES第一次
//
//  Created by 李金蔚 on 16/8/12.
//  Copyright © 2016年 SYP. All rights reserved.
//

#import "ELSession.h"

@implementation ELSession

+(instancetype)sessionWithDict:(NSDictionary *)dict{
    ELSession * session =[[ELSession alloc]init];
    session.sessionId =dict[@"sessionId"];
    return session;
}
-(void)encodeWithCoder:(NSCoder *)encoder{
    [encoder encodeObject:self.sessionId forKey:@"sessionId"];
}

-(id)initWithCoder:(NSCoder *)decoder{
    if (self =[super init]) {
        self.sessionId =[decoder decodeObjectForKey:@"sessionId"];
    }
    return self;
}

@end
