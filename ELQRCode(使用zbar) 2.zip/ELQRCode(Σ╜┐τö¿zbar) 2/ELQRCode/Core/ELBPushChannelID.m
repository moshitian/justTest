//
//  ELBPushChannelID.m
//  HuaXiaELife
//
//  Created by 李金蔚 on 17/1/3.
//  Copyright © 2017年 SYP. All rights reserved.
//

#import "ELBPushChannelID.h"

@implementation ELBPushChannelID

+(instancetype)bPushChannelIdWithDict:(NSDictionary *)dict{
    
    ELBPushChannelID * bpushChannelId =[[ELBPushChannelID alloc] init];
    bpushChannelId.bpushChannelId = dict[@"bpushChannelId"];
    return bpushChannelId;
}
-(void)encodeWithCoder:(NSCoder *)encoder{
    [encoder encodeObject:self.bpushChannelId forKey:@"bpushChannelId"];
}

-(id)initWithCoder:(NSCoder *)decoder{
    if (self =[super init]) {
        self.bpushChannelId =[decoder decodeObjectForKey:@"bpushChannelId"];
    }
    return self;
}

@end
