//
//  ELUserID.m
//  HuaXiaELife
//
//  Created by 李金蔚 on 16/9/3.
//  Copyright © 2016年 SYP. All rights reserved.
//

#import "ELUserID.h"

@implementation ELUserID

+(instancetype)sessionWithDict:(NSDictionary *)dict{
    ELUserID * user =[[ELUserID alloc]init];
    user.userId =dict[@"userId"];
    return user;
}
-(void)encodeWithCoder:(NSCoder *)encoder{
    [encoder encodeObject:self.userId forKey:@"userId"];
}

-(id)initWithCoder:(NSCoder *)decoder{
    if (self =[super init]) {
        self.userId =[decoder decodeObjectForKey:@"userId"];
    }
    return self;
}

@end
