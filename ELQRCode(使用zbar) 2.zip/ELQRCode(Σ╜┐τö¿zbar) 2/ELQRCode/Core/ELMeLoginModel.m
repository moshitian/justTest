//
//  ELMeLoginModel.m
//  HuaXiaELife
//
//  Created by 李金蔚 on 16/10/11.
//  Copyright © 2016年 SYP. All rights reserved.
//

#import "ELMeLoginModel.h"

@implementation ELMeLoginModel

+(instancetype)saveUserInfoFormLoginDict:(NSDictionary *)dict{
    ELMeLoginModel * loginModel = [[ELMeLoginModel alloc]init];
    loginModel.userId = dict[@"userId"];
    loginModel.userPhoto = dict[@"userPhoto"];
    loginModel.mobile = dict[@"mobile"];
    loginModel.userName = dict[@"userName"];
    loginModel.userSex = dict[@"userSex"];
    loginModel.registTime = dict[@"registTime"];
    loginModel.manageFlag = dict[@"manageFlag"];
    loginModel.code = dict[@"code"];
    loginModel.departmentName = dict[@"departmentName"];
    loginModel.checkFlag = dict[@"checkFlag"];
    
//    loginModel.isBindMobile = dict[@"isBindMobile"];
//    loginModel.communityName = dict[@"communityName"];
//    loginModel.regionAddress = dict[@"regionAddress"];
//    loginModel.detailAddress = dict[@"detailAddress"];
//    loginModel.regionCode = dict[@"regionCode"];
//    loginModel.communityId = dict[@"communityId"];
    return loginModel;
}

-(void)encodeWithCoder:(NSCoder *)encoder{
    [encoder encodeObject:self.userId forKey:@"userId"];
    [encoder encodeObject:self.userPhoto forKey:@"userPhoto"];
    [encoder encodeObject:self.mobile forKey:@"mobile"];
    [encoder encodeObject:self.userName forKey:@"userName"];
    [encoder encodeObject:self.userSex forKey:@"userSex"];
    [encoder encodeObject:self.registTime forKey:@"registTime"];
    [encoder encodeObject:self.manageFlag forKey:@"manageFlag"];
    [encoder encodeObject:self.code forKey:@"code"];
    [encoder encodeObject:self.departmentName forKey:@"departmentName"];
    [encoder encodeObject:self.checkFlag forKey:@"checkFlag"];
    
//    [encoder encodeObject:self.isBindMobile forKey:@"isBindMobile"];
//    [encoder encodeObject:self.communityName forKey:@"communityName"];
//    [encoder encodeObject:self.regionAddress forKey:@"regionAddress"];
//    [encoder encodeObject:self.detailAddress forKey:@"detailAddress"];
//    [encoder encodeObject:self.regionCode forKey:@"regionCode"];
//    [encoder encodeObject:self.communityId forKey:@"communityId"];
}

-(id)initWithCoder:(NSCoder *)decoder{
    
    if (self =[super init]) {
        self.userId =[decoder decodeObjectForKey:@"userId"];
        self.userPhoto =[decoder decodeObjectForKey:@"userPhoto"];
        self.mobile =[decoder decodeObjectForKey:@"mobile"];
        self.userName =[decoder decodeObjectForKey:@"userName"];
        self.userSex =[decoder decodeObjectForKey:@"userSex"];
        self.registTime =[decoder decodeObjectForKey:@"registTime"];
        self.manageFlag = [decoder decodeObjectForKey:@"manageFlag"];
        self.code = [decoder decodeObjectForKey:@"code"];
        self.departmentName = [decoder decodeObjectForKey:@"departmentName"];
        self.checkFlag = [decoder decodeObjectForKey:@"checkFlag"];
//        self.isBindMobile = [decoder decodeObjectForKey:@"isBindMobile"];
//        self.communityName =[decoder decodeObjectForKey:@"communityName"];
//        self.regionAddress =[decoder decodeObjectForKey:@"regionAddress"];
//        self.detailAddress =[decoder decodeObjectForKey:@"detailAddress"];
//        self.regionCode = [decoder decodeObjectForKey:@"regionCode"];
//        self.communityId = [decoder decodeObjectForKey:@"communityId"];
    }
    return self;
}

-(id)copyWithZone:(NSZone *)zone{
    
    //Value stored to 'loginModel' during its initialization is never read
    ELMeLoginModel * loginModel = nil;
    loginModel = self;
    return loginModel;
}


@end











