//
//  ELMeLoginModel.h
//  HuaXiaELife
//
//  Created by 李金蔚 on 16/10/11.
//  Copyright © 2016年 SYP. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ELMeLoginModel : NSObject <NSCoding,NSCopying>
/**用户id*/
@property(nonatomic,strong)NSString * userId;
/**头像*/
@property(nonatomic,strong)NSURL    * userPhoto;
/**登录名*/
@property(nonatomic,strong)NSString * mobile;
/**用户名*/
@property(nonatomic,strong)NSString * userName;
/**性别*/
@property(nonatomic,strong)NSString * userSex;
/**吸存号*/
@property(nonatomic,strong)NSString * code;
/**机构名称*/
@property(nonatomic,strong)NSString * departmentName;
/**注册时间*/
@property(nonatomic,strong)NSString * registTime;
/**所在社区*/
//@property(nonatomic,strong)NSString * communityName;
/**所在区域*/
//@property(nonatomic,strong)NSString * regionAddress;
/**详细地址*/
//@property(nonatomic,strong)NSString * detailAddress;
/**区域id*/
//@property(nonatomic,strong)NSString * regionCode;
/**社区id*/
//@property(nonatomic,strong)NSString * communityId;
//0否1是
@property(nonatomic,strong)NSString * manageFlag;
/*
 查看权限：
 0-无 ；
 1-分行最高权限 ；
 2-分行二级权限，除华夏菁英榜模块外可查看所有
 11-支行最高权限，可查看支行所有；
 12-支行二级权限，除华夏菁英榜模块外可查看所有
 */
@property(nonatomic,strong)NSString * checkFlag;

+(instancetype)saveUserInfoFormLoginDict:(NSDictionary *)dict;

@end






