//
//  ELSession.h
//  DES第一次
//
//  Created by 李金蔚 on 16/8/12.
//  Copyright © 2016年 SYP. All rights reserved.
//

#import <Foundation/Foundation.h>
//归档sessionId
@interface ELSession : NSObject<NSCoding>
@property(nonatomic,strong)NSString * sessionId;

+(instancetype)sessionWithDict:(NSDictionary *)dict;


@end
