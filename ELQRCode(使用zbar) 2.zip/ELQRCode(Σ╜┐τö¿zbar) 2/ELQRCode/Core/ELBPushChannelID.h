//
//  ELBPushChannelID.h
//  HuaXiaELife
//
//  Created by 李金蔚 on 17/1/3.
//  Copyright © 2017年 SYP. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ELBPushChannelID : NSObject<NSCoding>
@property(nonatomic,strong)NSString * bpushChannelId;

+(instancetype)bPushChannelIdWithDict:(NSDictionary *)dict;
@end
