//
//  ELHttpClient.h
//  ELQRCode
//
//  Created by 李金蔚 on 17/8/7.
//  Copyright © 2017年 SYP. All rights reserved.
//

#import <Foundation/Foundation.h>

//回调封装的网络请求的返回数据
typedef void(^getResult)(NSDictionary *json);

//typedef void(^getError) (NSError * error);

@interface ELHttpClient : NSObject

@property (nonatomic, strong) NSString * bpushChannelId;

+ (instancetype)shareManage;
//第一次请求
- (void)PamramsResultOne;
//正常请求
- (void)PamramsResultTwoWithParameter:(NSDictionary *)Parameter URL:(NSString *)url result:(getResult)getResult;
//上传图片
- (void)uploadImageResultWithParameter:(NSDictionary *)Parameter Image:(UIImage *)photo URL:(NSString *)url result:(getResult)getResult;
@end
