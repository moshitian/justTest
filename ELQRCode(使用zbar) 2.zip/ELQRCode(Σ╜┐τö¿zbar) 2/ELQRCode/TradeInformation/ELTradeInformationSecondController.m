//
//  ELTradeInformationSecondController.m
//  ELQRCode
//
//  Created by 李金蔚 on 17/8/9.
//  Copyright © 2017年 SYP. All rights reserved.
//

#import "ELTradeInformationSecondController.h"

@interface ELTradeInformationSecondController ()
@property(nonatomic,strong)NSString * text;
@end

@implementation ELTradeInformationSecondController



-(instancetype)initWithScanContent:(NSString *)text{
    if (self = [super initWithNibName:nil bundle:nil]) {
        self.title = @"商品信息";
        self.text = text;
    }
    return self;
}


-(void)setupSubviews{
    self.view.backgroundColor = [UIColor whiteColor];
    UILabel * label = [[UILabel alloc] initWithFrame:CGRectMake(30, 100, 180, 30)];
    label.text = self.text;
    [label sizeToFit];
    [self.view addSubview:label];
}

@end




