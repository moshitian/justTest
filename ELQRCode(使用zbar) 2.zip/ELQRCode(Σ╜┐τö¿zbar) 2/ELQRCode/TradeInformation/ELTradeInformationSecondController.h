//
//  ELTradeInformationSecondController.h
//  ELQRCode
//
//  Created by 李金蔚 on 17/8/9.
//  Copyright © 2017年 SYP. All rights reserved.
//

#import "ViewController.h"

@interface ELTradeInformationSecondController : ViewController
- (instancetype)initWithScanContent:(NSString *)text;
@end
