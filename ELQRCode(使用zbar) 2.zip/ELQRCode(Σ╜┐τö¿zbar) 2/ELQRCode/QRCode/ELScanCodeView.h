//
//  ELScanCodeView.h
//  ELQRCode
//
//  Created by 李金蔚 on 17/9/11.
//  Copyright © 2017年 SYP. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ELScanCodeView : UIView

@end
