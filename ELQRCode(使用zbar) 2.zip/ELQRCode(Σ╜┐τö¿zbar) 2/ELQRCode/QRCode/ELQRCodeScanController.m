//
//  ELQRCodeScanController.m
//  ELQRCode
//
//  Created by 李金蔚 on 17/8/9.
//  Copyright © 2017年 SYP. All rights reserved.
//

#import "ELQRCodeScanController.h"

#import "ELScanCodeView.h"
#import <AVFoundation/AVFoundation.h>
//#import "ZBarSDK.h"
//#import "ELTradeInformationSecondController.h"
//
#define screenWidth   [UIScreen mainScreen].bounds.size.width

#define screenHeight  [UIScreen mainScreen].bounds.size.height

//#define scanContent_Y 120

///** 二维码冲击波动画时间 */
//static CGFloat const SGQRCodeScanningLineAnimation = 0.05;
///** 扫描动画线(冲击波) 的高度 */
//static CGFloat const scanninglineHeight = 12;

@interface ELQRCodeScanController () <AVCaptureMetadataOutputObjectsDelegate>//<ZBarReaderViewDelegate>
//{
//    ZBarReaderView * readView;
//    UIImageView * scanZomeBack;
//    UIView * readLineView;
//}
//@property (nonatomic, strong) UIImageView *scanningline;
//@property (nonatomic, strong) NSTimer *timer;
//


@property (nonatomic,strong)AVCaptureDevice            *device;
@property (nonatomic,strong)AVCaptureDeviceInput       *input;
@property (nonatomic,strong)AVCaptureMetadataOutput    *output;
@property (nonatomic,strong)AVCaptureSession           *session;
@property (nonatomic,strong)AVCaptureVideoPreviewLayer *preview;
@property (weak, nonatomic) IBOutlet UIButton *button;


@end

@implementation ELQRCodeScanController

-(instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        self.title = @"扫描";
        self.tabBarItem = [[UITabBarItem alloc] initWithTitle:self.title image:[[UIImage imageNamed:@"tab01_normal"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] selectedImage:[[UIImage imageNamed:@"tab01_click"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    }
    return self;
}

//-(void)dealloc{
//    [self removeTimer];
//}
//- (void)viewDidAppear:(BOOL)animated {
//    [super viewDidAppear:animated];
//    
//    [self addTimer];
//}
//
//-(void)setupSubviews{
//    
//    readView = [ZBarReaderView new];
//    readView.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
//    readView.backgroundColor = [UIColor clearColor];
//    readView.layer.borderWidth = 0;
//    readView.layer.borderColor = [UIColor redColor].CGColor;
//    //使用手势变焦
//    readView.allowsPinchZoom = NO;
//    //关闭闪光灯
//    readView.torchMode = 0;
//    
//    // 设置代理
//    readView.readerDelegate = self;
//    
//    // 将其照相机拍摄视图添加到要显示的视图上
//    [self.view addSubview:readView];
//    
//    // 左上侧的image
//    UIImage *left_image = [UIImage imageNamed:@"QRCodeTopLeft"];
//    UIImageView *left_imageView = [[UIImageView alloc] init];
//    
//    left_imageView.frame = CGRectMake((screenWidth-200-16)/2.0, 120, 16, 16);
//    left_imageView.image = left_image;
//    [self.view addSubview:left_imageView];
//    
//    // 右上侧的image
//    UIImage *right_image = [UIImage imageNamed:@"QRCodeTopRight"];
//    UIImageView *right_imageView = [[UIImageView alloc] init];
//    right_imageView.frame = CGRectMake(CGRectGetMinX(left_imageView.frame)+200, 120, 16, 16);
//    right_imageView.image = right_image;
//    [self.view addSubview:right_imageView];
//    
//    // 左下侧的image
//    UIImage *left_image_down = [UIImage imageNamed:@"QRCodebottomLeft"];
//    UIImageView *left_imageView_down = [[UIImageView alloc] init];
//    left_imageView_down.frame = CGRectMake((screenWidth-200-16)/2.0, CGRectGetMinY(left_imageView.frame)+200, 16, 16);
//    left_imageView_down.image = left_image_down;
//    [self.view addSubview:left_imageView_down];
//    
//    // 右下侧的image
//    UIImage *right_image_down = [UIImage imageNamed:@"QRCodebottomRight"];
//    UIImageView *right_imageView_down = [[UIImageView alloc] init];
//    
//    right_imageView_down.frame = CGRectMake(CGRectGetMinX(left_imageView_down.frame)+200, CGRectGetMinY(left_imageView.frame)+200, 16, 16);
//    right_imageView_down.image = right_image_down;
//    [self.view addSubview:right_imageView_down];
//    
//    
//    UILabel * textLabel = [[UILabel alloc] initWithFrame:CGRectMake((screenWidth-216)/2.0, CGRectGetMaxY(right_imageView_down.frame)+30, 216, 30)];
//    textLabel.text = @"将二维码/条码放入框内，即可自动扫描";
//    textLabel.textAlignment = NSTextAlignmentCenter;
//    textLabel.textColor = [UIColor whiteColor];
//    textLabel.font = [UIFont systemFontOfSize:12];
//    [self.view addSubview:textLabel];
//    
//    // 二维码 条形码识别设置
//    ZBarImageScanner * scanner = readView.scanner;
//    [scanner setSymbology:ZBAR_I25 config:ZBAR_CFG_ENABLE to:0];
//    
//    // 启动，必须启动后，手机摄像头拍摄的即时图像才可以显示在readview上
//    [readView start];
//}
//- (UIImageView *)scanningline {
//    if (!_scanningline) {
//        _scanningline = [[UIImageView alloc] init];
//        _scanningline.image = [UIImage imageNamed:@"QRCodeLine"];
//        //300
//        _scanningline.frame = CGRectMake((screenWidth-300)/2.0,scanContent_Y, 300, scanninglineHeight);
//    }
//    return _scanningline;
//}
//
//- (void)addScanningline {
//    // 扫描动画添加
//    [self.view addSubview:self.scanningline];
//}
//
//#pragma mark - - - 添加定时器
//- (void)addTimer {
//    [self addScanningline];
//    
//    self.timer = [NSTimer scheduledTimerWithTimeInterval:SGQRCodeScanningLineAnimation target:self selector:@selector(timeAction) userInfo:nil repeats:YES];
//    [[NSRunLoop mainRunLoop] addTimer:_timer forMode:NSRunLoopCommonModes];
//}
//#pragma mark - - - 移除定时器
//- (void)removeTimer {
//    [self.timer invalidate];
//    self.timer = nil;
//    [self.scanningline removeFromSuperview];
//    self.scanningline = nil;
//}
//
//#pragma mark - - - 执行定时器方法
//- (void)timeAction {
//    __block CGRect frame = _scanningline.frame;
//    
//    static BOOL flag = YES;
//    
//    if (flag) {
//        frame.origin.y = scanContent_Y;
//        flag = NO;
//        [UIView animateWithDuration:SGQRCodeScanningLineAnimation animations:^{
//            frame.origin.y += 5;
//            _scanningline.frame = frame;
//        } completion:nil];
//    } else {
//        if (_scanningline.frame.origin.y >= scanContent_Y) {
//            CGFloat scanContent_MaxY = scanContent_Y + 200;
//            if (_scanningline.frame.origin.y >= scanContent_MaxY - 10) {
//                frame.origin.y = scanContent_Y;
//                _scanningline.frame = frame;
//                flag = YES;
//            } else {
//                [UIView animateWithDuration:SGQRCodeScanningLineAnimation animations:^{
//                    frame.origin.y += 5;
//                    _scanningline.frame = frame;
//                } completion:nil];
//            }
//        } else {
//            flag = !flag;
//        }
//    }
//}
//
//
//#pragma ZBarReaderViewDelegate
//- (void)readerView:(ZBarReaderView *)readerView didReadSymbols:(ZBarSymbolSet *)symbols fromImage:(UIImage *)image {
//    
//    ZBarSymbol *symbol = nil;
//    for (symbol in symbols) {
//        break;
//    }
//    
//    NSString *text = symbol.data;
//
//    YYLog(@"扫描的内容是%@",text);
//    if (self.contentBlock) {
//        self.contentBlock(text);
//    }
//    [self.navigationController popViewControllerAnimated:YES];
//    
//    [readerView removeFromSuperview];
//}





//-(void)setupSubviews{
//    
//    ELScanCodeView * codeVeiw = [[ELScanCodeView alloc] initWithFrame:CGRectMake(0, 0, screenWidth, screenHeight)];
//    [self.view addSubview:codeVeiw];
//}





@end






















