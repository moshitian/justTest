//
//  ELRootViewController.h
//  ELQRCode
//
//  Created by 李金蔚 on 17/8/7.
//  Copyright © 2017年 SYP. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ELRootViewController : UITabBarController

@end
