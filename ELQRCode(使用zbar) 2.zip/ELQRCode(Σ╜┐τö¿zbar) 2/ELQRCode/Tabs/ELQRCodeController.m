//
//  ELQRCodeController.m
//  ELQRCode
//
//  Created by 李金蔚 on 17/8/7.
//  Copyright © 2017年 SYP. All rights reserved.
//

#import "ELQRCodeController.h"

#import "ELQRCodeScanController.h"

#define screenWidth   [UIScreen mainScreen].bounds.size.width

#define screenHeight  [UIScreen mainScreen].bounds.size.height

@interface ELQRCodeController ()
@property(nonatomic,strong) UILabel * label;
@end

@implementation ELQRCodeController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        self.title = @"扫描";
        self.tabBarItem = [[UITabBarItem alloc] initWithTitle:self.title image:[[UIImage imageNamed:@"icon-180"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] selectedImage:[[UIImage imageNamed:@"icon-180"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
        self.hidesBottomBarWhenPushed = NO;
    }
    return self;
}

- (void)setupSubviews{
    UIButton * button = [[UIButton alloc] initWithFrame:CGRectMake(100, 100, 100, 100)];
    [button addTarget:self action:@selector(startScan) forControlEvents:UIControlEventTouchUpInside];
    button.backgroundColor = [UIColor yellowColor];
    [self.view addSubview:button];
    
    self.label = [[UILabel alloc] initWithFrame:CGRectMake(30, 330, 180, 30)];
    self.label.backgroundColor = [UIColor redColor];
//    [self.label sizeToFit];
    [self.view addSubview:self.label];
    
}


- (void)startScan{
    
    ELQRCodeScanController * controller = [[ELQRCodeScanController alloc] init];
    weakify(self);
    controller.contentBlock = ^(NSString * text){
        strongify(self);
        self.label.text = text;
        YYLog(@"过段时间kgas记得个化解撒带和嘎哈受到攻击客户的换个撒个哈师大高考还打算开个会大卡司带和嘎哈时代光华");
    };
    [self.navigationController pushViewController:controller animated:YES];
}

@end





















