//
//  ELRootViewController.m
//  ELQRCode
//
//  Created by 李金蔚 on 17/8/7.
//  Copyright © 2017年 SYP. All rights reserved.
//

#import "ELRootViewController.h"


#import "ELTradeInformationController.h"
#import "ELQRCodeController.h"
#import "ELMeController.h"


@interface ELRootViewController ()
@property(nonatomic,strong)NSMutableArray *controllers;
@property(nonatomic,strong)UINavigationController * nav;
@end

@implementation ELRootViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupViewControllers];
}



-(void)setupViewControllers
{
    _controllers = [[NSMutableArray alloc] initWithCapacity:4];
    
    UIViewController * controller;
    controller =[[ELTradeInformationController alloc]init];
    [self addNavigationController:controller];
    controller =[[ELQRCodeController alloc]init];
    [self addNavigationController:controller];
    controller =[[ELMeController alloc]init];
    [self addNavigationController:controller];
    self.viewControllers = self.controllers;
    
}

-(void)addNavigationController:(UIViewController *)controller
{
    UINavigationController * nvc = [[UINavigationController alloc] initWithRootViewController:controller];
    [_controllers addObject:nvc];
    self.nav = nvc;
    
}
@end





