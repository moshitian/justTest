//
//  ELMeController.m
//  ELQRCode
//
//  Created by 李金蔚 on 17/8/7.
//  Copyright © 2017年 SYP. All rights reserved.
//

#import "ELMeController.h"

@interface ELMeController ()

@end

@implementation ELMeController


-(instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        self.title = @"我的";
        self.tabBarItem = [[UITabBarItem alloc] initWithTitle:self.title image:[[UIImage imageNamed:@"tab01_normal"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] selectedImage:[[UIImage imageNamed:@"tab01_click"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
        self.hidesBottomBarWhenPushed = NO;
    }
    return self;
}


-(void)setupSubviews{
    
}


@end
